let firstName: String = "Anel"
let lastName: String = "Bakhtygereyeva 🐯"
let birthYear: Int = 2006
var currentYear: Int = 2025
let age = currentYear - birthYear
let isStident: Bool = true
let height: Double = 1.68

var currentCountry: String = "Kazakhstan 🇰🇿"
var favoriteFood: String = "korean cousine 🇰🇷🍚🥢"

var hobby: String = "playing musical instruments 🎹🎸 and drawing 🎨"
var numberOfHobbies: Int = 1045
var favoriteNumber: Int = 87
var isHobbyCreative: Bool = true
var favoriteInstrment: String = "piano 🎹"
let nativeLanguage: String = "kazakh 🇰🇿🗣️"
var learningLanguage: String = "Japanese 🇯🇵"
var fluentLanguages: Int = 3
var gpa: Double = 3.65

var futureGoals: String = "In the near future, I really want to become a professional iOS developer 👩‍💻📱 and get an offer in big tech company 💼"


let lifeStory = """
Hello, my name is \(firstName) \(lastName). I am \(age) years old now, and was born in \(birthYear)🙀.
Am I currently a student: \(isStident). My height is \(height) meters.
Nowadays I live in \(currentCountry). My favorite food is \(favoriteFood).
I enjoy \(hobby). My favorite instrument is the \(favoriteInstrment).
Are my hobbies creative?: \(isHobbyCreative).
I have \(numberOfHobbies) hobbies in total😂, and my favorite number is \(favoriteNumber), idk why🤷🏻.
My native language is \(nativeLanguage), of course. I am currently learning \(learningLanguage) for fun.
I can speak \(fluentLanguages) languages fluently. My GPA is \(gpa), hope it will have upward trend only📈.

\(futureGoals)
"""
print(lifeStory)

